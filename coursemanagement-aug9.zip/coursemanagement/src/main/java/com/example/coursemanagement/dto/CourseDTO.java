//package com.example.coursemanagement.dto;
//
//import java.util.Date;
//
//public class CourseDTO {
//    private Long courseId;
//    private String courseName;
//    private String description;
//    private String durationInMonth;
//    private Date assignedDate;
//    private Date endDate;
//    private Long teacherId; // Just include the teacherId, not the entire teacher object
//
//
//
//    // Getters and setters
//    public Long getCourseId() { return courseId; }
//    public void setCourseId(Long courseId) { this.courseId = courseId; }
//    public String getCourseName() { return courseName; }
//    public void setCourseName(String courseName) { this.courseName = courseName; }
//    public String getDescription() { return description; }
//    public void setDescription(String description) { this.description = description; }
//    public String getDurationInMonth() { return durationInMonth; }
//    public void setDurationInMonth(String durationInMonth) { this.durationInMonth = durationInMonth; }
//    public Date getAssignedDate() { return assignedDate; }
//    public void setAssignedDate(Date assignedDate) { this.assignedDate = assignedDate; }
//    public Date getEndDate() { return endDate; }
//    public void setEndDate(Date endDate) { this.endDate = endDate; }
//    public Long getTeacherId() { return teacherId; }
//    public void setTeacherId(Long teacherId) { this.teacherId = teacherId; }
//}
